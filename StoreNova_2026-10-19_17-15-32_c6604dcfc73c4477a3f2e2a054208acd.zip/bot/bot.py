from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InlineQueryResultArticle, InputTextMessageContent
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, MessageHandler, ConversationHandler, InlineQueryHandler, CallbackContext, filters
from bot.cogs.modules.database import *
from bot.cogs.modules.import_text_variables import *
from bot.cogs.modules.pix_authentication import *
from bot.cogs.modules.pix_key_check import *
from bot.cogs.estatisticas import *
from bot.cogs.ban import *
from bot.cogs.add_cc import *
from bot.cogs.troca import *
from bot.cogs.tools import *
from bot.cogs.add_credits import *
from bot.cogs.add_pix_config import *
from bot.cogs.afilliate import *
from bot.cogs.add_groups import *
from bot.cogs.buy import *
from bot.cogs.cc_main import *
from bot.cogs.delete_account import *
from bot.cogs.dynamic_buttons import *
from bot.cogs.gift import *
from bot.cogs.history import *
from bot.cogs.mix import *
from bot.cogs.profile import *
from bot.cogs.scheduled_tasks import *
from bot.cogs.search import *
from bot.cogs.send import *
from bot.cogs.start import *
from bot.cogs.add_admin import *
from bot.cogs.flags import *
from bot.cogs.users import *
from bot.cogs.delete_card import *
from bot.cogs.backup import *
import json, logging, threading, os, time


logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)


def main():
    with open('config/config.json', 'r', encoding="utf8") as file:
        config = json.loads(file.read())
        token_bot = config['token_bot']

    print('\nBot online\n')

    application = ApplicationBuilder().token(token_bot).build()

    for command in add_admin_command:
        application.add_handler(CommandHandler(command, add_admin))

    for command in remove_admin_command:
        application.add_handler(CommandHandler(command, remove_admin))

    for command in send_command:
        application.add_handler(CommandHandler(command, send))

    for command in start_command:
        application.add_handler(CommandHandler(command, start))

    for command in add_credits:
        application.add_handler(CommandHandler(command, recarregar))

    for command in add_cc:
        application.add_handler(CommandHandler(command, adicionar_cc))

    for command in card:
        application.add_handler(CommandHandler(command, cartao))

    for command in edit_prices:
        application.add_handler(CommandHandler(command, editar_precos))

    for command in gift_add:
        application.add_handler(CommandHandler(command, adicionar_gift))

    for command in gift_gen_command:
        application.add_handler(CommandHandler(command, gerar_gift))

    for command in create_table:
        application.add_handler(CommandHandler(command, criar_mix))

    for command in menu_pix_command:
        application.add_handler(CommandHandler(command, menu_pix))

    application.add_handler(CommandHandler('configuracoes', flags))
    application.add_handler(CommandHandler('notificaraqui', add_groups))
    application.add_handler(CommandHandler('chk', chk))
    application.add_handler(CommandHandler('separador', separador))
    application.add_handler(CommandHandler('baixarusuarios', baixar_usuarios))
    application.add_handler(CommandHandler('resaldo', resaldo))
    application.add_handler(CommandHandler('deletarcartoes', delete_all_cards))
    application.add_handler(CommandHandler('deletarccs', delete_all_cards))
    application.add_handler(CommandHandler('backup', download_backup))
    application.add_handler(CommandHandler('estatisticas', estatisticas))
    application.add_handler(CommandHandler('relatorio', estatisticas))
    application.add_handler(CommandHandler('usuario', usuario))
    application.add_handler(CommandHandler('usuarios', pesquisarusuario))


    application.add_handler(InlineQueryHandler(inlinequery))

    application.add_handler(CallbackQueryHandler(delete_all_cards, pattern='delete_cards_yes'))
    application.add_handler(CallbackQueryHandler(delete_card, pattern='remove_'))
    application.add_handler(CallbackQueryHandler(ferramentas, pattern='ferramentas'))
    application.add_handler(CallbackQueryHandler(edit_mp, pattern='edit_mp'))
    application.add_handler(CallbackQueryHandler(edit_mp, pattern='default_mp'))
    application.add_handler(CallbackQueryHandler(edit_mp, pattern='delete_mp'))
    application.add_handler(CallbackQueryHandler(edit_gn, pattern='edit_gn'))
    application.add_handler(CallbackQueryHandler(edit_gn, pattern='default_gn'))
    application.add_handler(CallbackQueryHandler(edit_gn, pattern='delete_gn'))
    application.add_handler(CallbackQueryHandler(edit_key, pattern='edit_key'))
    application.add_handler(CallbackQueryHandler(edit_key, pattern='default_key'))
    application.add_handler(CallbackQueryHandler(edit_key, pattern='delete_key'))
    application.add_handler(CallbackQueryHandler(menu_pix, pattern='main_pix'))
    application.add_handler(CallbackQueryHandler(menu_pix_criados, pattern='menu_pix_criados'))
    application.add_handler(CallbackQueryHandler(add_key_pix_start, pattern='key_menu_pix'))
    application.add_handler(CallbackQueryHandler(add_gn_pix_start, pattern='gn_menu_pix'))
    application.add_handler(CallbackQueryHandler(add_mp_pix_start, pattern='mp_menu_pix'))
    application.add_handler(CallbackQueryHandler(add_pix, pattern='menu_pix'))
    application.add_handler(CallbackQueryHandler(add_key_pix0, pattern='criar_pix_key'))
    application.add_handler(CallbackQueryHandler(recarregar, pattern='r_'))
    application.add_handler(CallbackQueryHandler(confirmar_compra_mix, pattern='comprarmix_'))
    application.add_handler(CallbackQueryHandler(comprar_mix, pattern='>'))
    application.add_handler(CallbackQueryHandler(add_key_pix0, pattern='criar_pix_key'))
    application.add_handler(CallbackQueryHandler(ban, pattern='ban_'))
    application.add_handler(CallbackQueryHandler(unban, pattern='unban_'))

    application.add_handler(CallbackQueryHandler(usuario, pattern='usuario_'))
    application.add_handler(CallbackQueryHandler(menu, pattern='termos'))
    application.add_handler(CallbackQueryHandler(cancelar_compra, pattern='cancelar_compra'))
    application.add_handler(CallbackQueryHandler(preco_unitaria, pattern='cancelar_edicao1'))
    application.add_handler(CallbackQueryHandler(preco_mix, pattern='cancelar_edicao2'))
    application.add_handler(CallbackQueryHandler(unitaria, pattern='unitaria'))
    application.add_handler(CallbackQueryHandler(adicionar_saldo, pattern='adicionar_saldo'))
    application.add_handler(CallbackQueryHandler(aleatoria, pattern='aleatoria'))
    application.add_handler(CallbackQueryHandler(baixar_historico, pattern='baixar_historico'))
    application.add_handler(CallbackQueryHandler(encerrar_conta, pattern='encerrar_conta'))
    application.add_handler(CallbackQueryHandler(menu, pattern='main'))
    application.add_handler(CallbackQueryHandler(historico, pattern='m3'))
    application.add_handler(CallbackQueryHandler(informacoes, pattern='m2'))
    application.add_handler(CallbackQueryHandler(comprar, pattern='m1'))
    application.add_handler(CallbackQueryHandler(mix, pattern='mix'))
    application.add_handler(CallbackQueryHandler(afiliados, pattern='afiliados'))
    application.add_handler(CallbackQueryHandler(encerrar_conta, pattern='encerrar_conta_sim'))
    application.add_handler(CallbackQueryHandler(preco_mix, pattern='editar_mix'))
    application.add_handler(CallbackQueryHandler(preco_unitaria, pattern='editar_unitaria'))
    application.add_handler(CallbackQueryHandler(editar_precos, pattern='editar_precos'))
    application.add_handler(CallbackQueryHandler(cancel, pattern='cancelar_criacao_pix_mp'))
    application.add_handler(CallbackQueryHandler(send, pattern='delete_message'))
    application.add_handler(CallbackQueryHandler(add_admin_button, pattern='add_admin_'))
    application.add_handler(CallbackQueryHandler(remove_admin_button, pattern='rm_admin_'))
    application.add_handler(CallbackQueryHandler(flags, pattern='flag_'))
    application.add_handler(CallbackQueryHandler(search, pattern='search'))
    application.add_handler(CallbackQueryHandler(troca, pattern='troca'))
    application.add_handler(CallbackQueryHandler(estatisticas, pattern='stats_'))


    conv_handler_gn = ConversationHandler(
        entry_points=[CallbackQueryHandler(add_gn_pix, pattern='criar_pix_gn')],
        states={
            STEP1: [MessageHandler(filters.Document & ~filters.Command, add_gn_pix2)],
            STEP2: [MessageHandler(filters.Text & ~filters.Command, add_gn_pix3)],
            STEP3: [MessageHandler(filters.Text & ~filters.Command, add_gn_pix4)],
            STEP4: [MessageHandler(filters.Text & ~filters.Command, add_gn_pix5)]
        },
        fallbacks=[CallbackQueryHandler(cancel, pattern='cancelar_criacao_pix_gn')],
    )

    conv_handler_mp = ConversationHandler(
        entry_points=[CallbackQueryHandler(add_mp_pix, pattern='criar_pix_mp')],
        states={
            STEP1: [MessageHandler(filters.Text & ~filters.Command, add_mp_pix2)],
        },
        fallbacks=[CallbackQueryHandler(cancel, pattern='cancelar_criacao_pix_mp')],
    )

    conv_handler_key = ConversationHandler(
        entry_points=[CallbackQueryHandler(add_key_pix1, pattern='pix_cpf'),
                    CallbackQueryHandler(add_key_pix1, pattern='pix_cnpj'),
                    CallbackQueryHandler(add_key_pix1, pattern='pix_email'),
                    CallbackQueryHandler(add_key_pix1, pattern='pix_telefone'),
                    CallbackQueryHandler(add_key_pix1, pattern='pix_aleatoria')],
        states={
            STEP1: [MessageHandler(filters.Text & ~filters.Command, add_key_pix2)],
        },
        fallbacks=[CallbackQueryHandler(cancel, pattern='cancelar_criacao_pix_key')],
    )

    application.add_handler(conv_handler_gn)
    application.add_handler(conv_handler_mp)
    application.add_handler(conv_handler_key)

    send_commands_list = []
    for command in send_command:
        send_commands_list.append('/'+command)

    j = application.job_queue

    try:
        j.run_repeating(payment_checker, interval=120, first=120)
    except: pass
    try:
        j.run_repeating(scheduled_tasks, interval=3600, first=3600)
    except: pass
    try:
        j.run_repeating(backup_task, interval=43200, first=43200)
    except: pass

    application.run_polling(
        poll_interval=0.5,
        timeout=100,
        bootstrap_retries=100,
        read_latency=1.0,
        allowed_updates=None,
        drop_pending_updates=True,
    )


if __name__ == '__main__':
    main()