# squarecloud.app
DISPLAY_NAME=StoreNova
MAIN=main.py
MEMORY=1858
VERSION=recommended
