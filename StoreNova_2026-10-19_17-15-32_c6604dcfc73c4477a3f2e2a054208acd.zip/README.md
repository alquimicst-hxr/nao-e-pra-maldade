# haxorstore_bot
Bot sendo reconstruído!

## Instalação:

**1.** Clone esse repositório

**2.** Instale as dependências com o comando: `pip3 install -r requirements.txt `

**3.** Edite as credenciais em `/config`

**4.** No diretório principal, xecute: `python3 main.py`
